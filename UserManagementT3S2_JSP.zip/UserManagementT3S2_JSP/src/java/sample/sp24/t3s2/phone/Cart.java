package sample.sp24.t3s2.phone;
import java.util.HashMap;
import java.util.Map;
import sample.sp24.t3s2.phone.Phone;

public class Cart {

    private Map<String, Phone> cart;

    public Cart() {
    }

    public Cart(Map<String, Phone> cart) {
        this.cart = cart;
    }

    public Map<String, Phone> getCart() {
        return cart;
    }

    public void setCart(Map<String, Phone> cart) {
        this.cart = cart;
    }

    public boolean add(Phone phone) {
        boolean check = false;
        try {
            if (this.cart == null) {
                this.cart = new HashMap<>();
            }
            if (this.cart.containsKey(phone.getId())) {
                int currentQuantity = this.cart.get(phone.getId()).getQuantity();
                phone.setQuantity(currentQuantity + phone.getQuantity());

            }
            this.cart.put(phone.getId(), phone);
            check = true;
        } catch (Exception e) {
        }
        return check;
    }

    public boolean edit(String id, int quantity) {
        boolean check = false;
        try {
            if (this.cart != null) {
            if (this.cart.containsKey(id)) {
                Phone phone = this.cart.get(id);
                phone.setQuantity(quantity);
                this.cart.replace(id, phone);
            }
        }
    }
    catch (Exception e){
    }
    return check ;
}
    
    public boolean remove(String id) {

        boolean check = false;

        try {
            if (this.cart != null) {
                if (this.cart.containsKey(id)) {
                    this.cart.remove(id);
                }
                }
            }catch (Exception e) {
                }
                return check;
            }
    
}
