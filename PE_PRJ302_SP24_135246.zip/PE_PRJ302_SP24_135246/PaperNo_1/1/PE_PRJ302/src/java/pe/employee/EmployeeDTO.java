package pe.employee;

import java.sql.Date;

public class EmployeeDTO {
    private int id;
    private String fullName;
    private Date dob;
    private float salary;

    public EmployeeDTO() {
    }

    public EmployeeDTO(int id, String fullName, Date dob, float salary) {
        this.id = id;
        this.fullName = fullName;
        this.dob = dob;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
    
    
}
