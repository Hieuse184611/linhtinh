package pe.employee;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.utils.DBUtils;

public class EmployeeDAO {

    private static final String SEARCH = "SELECT id, fullName, dob, salary FROM employee";

    public List<EmployeeDTO> getAll() throws SQLException {
        List<EmployeeDTO> listUser = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(SEARCH);
                rs = ptm.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String fullName = rs.getString("fullName");
                    Date date = rs.getDate("dob");
                    float salary = rs.getFloat("salary");
                    EmployeeDTO user = new EmployeeDTO(id, fullName, date, salary);
                    listUser.add(user);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs == null) {
                rs.close();
            }
            if (ptm == null) {
                ptm.close();
            }
            if (conn == null) {
                conn.close();
            }
        }
        return listUser;
    }
    //your code here

}
